/*
 * LeftPanel.java file
 * Contains all the buttons in the LeftPanel on the screen
 */

/*
 * Package location
 */

package nl.ru.ai.panels;

/*
 * Import packages?
 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;

import javax.swing.JPanel;

import nl.ru.ai.objects.Buttons;
import nl.ru.ai.objects.Labels;

/*
 * LeftPanel class
 * 
 * JPanel = superclass
 * LeftPanel = subclass
 * 
 * The extending class becomes a subclass, it inherits the methods and variables of the superclass.
 */

public class LeftPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
	DrawPanel DP;
	Labels Notifications;
	RightPanel RP;
	
	public LeftPanel (Labels Notifications, DrawPanel DP,RightPanel RP) {
		super (); // `super ' calls a function inherited from the parent class ( JPanel )
		this.DP = DP;
		this.Notifications = Notifications;
		this.RP = RP;
		

		
		/* PANEL SETTINGS - START */
		setPreferredSize(new Dimension(80, Window.HEIGHT)); // Set fixed size
		setBackground(Color.DARK_GRAY); // Set background color
		/* PANEL SETTINGS - END */
		
		
		/* TOOLS - START */
		Labels labelT = new Labels("Tools",80);
		add(labelT);
		
		// Add a button to the panel . The argument to the JButton constructor will become the text on the button .
		Buttons Draw = new Buttons("Draw",30,30,Notifications,"src/img/draw.png","Draw shapes",DP,RP);
		Draw.setActionCommand("Draw");
		add (Draw);
		
		Buttons Move = new Buttons("Move",30,30,Notifications,"src/img/move.png","Move shapes",DP,RP);
		Move.setActionCommand("Move");
		add (Move);
		
		Buttons Delete= new Buttons("Delete",30,30,Notifications,"src/img/delete.png","Delete shapes",DP,RP);
		Delete.setActionCommand("Delete");
		add (Delete);
		/* TOOLS - END */
		
		
		/* SHAPES - START */
		Labels labelS = new Labels("Shapes",80); // Shape label
		add(labelS);

		Buttons Rectangle = new Buttons("R",30,30,Notifications,"src/img/rectangle.png","Select rectangle",DP,RP); // Rectangle button
		Rectangle.setActionCommand("Rectangle");
		add (Rectangle);	
		
		Buttons Ellipse = new Buttons("E",30,30,Notifications,"src/img/ellipse.png","Select ellipse",DP,RP); // Ellipse button
		Ellipse.setActionCommand("Ellipse");
		add (Ellipse);
		
		Buttons Line = new Buttons("L",30,30,Notifications,"src/img/line.png","Select line",DP,RP); // Line button
		Line.setActionCommand("Line");
		add (Line);
		
		Buttons FreeForm = new Buttons("F",30,30,Notifications,"","Select free form",DP,RP); // Free Form button
		FreeForm.setActionCommand("Free");
		add (FreeForm);
		/* SHAPES - END */
	}
}