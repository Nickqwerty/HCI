package nl.ru.ai.handlers;

import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import nl.ru.ai.panels.DrawPanel;
import nl.ru.ai.shapes.*;

public class MouseMotionHandler implements MouseMotionListener{

	DrawPanel DP;
	static boolean delete = false;
	
	static double x1,y1,x2,y2;
	public MouseMotionHandler (DrawPanel DP) {
		this.DP = DP;
	}
	
	// Store MyLine coordinates
	double l1, l2;
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseDragged(MouseEvent e) {
		//x2 = e.getX();
    	//y2 = e.getY();
    	
    	//System.out.println(x2 + ", " + y2);
    	
    	// Store MyLine coordinates
    	 /*  1 = begin lijn horizontaal
		 * 2 = einde lijn horizontaal
		 * 3 = einde lijn verticaal
		 * 4 = begin lijn verticaal
		 * MyLine(x1,x2,y2,y1)
		 */
    	
    	//l1 = x1;
    	//l2 = y1;
    	
    	if(DP.mode == 0){
    		// if trigger to not delete the first placed shape
    		if(delete == true){
    			DP.deleteShapeB();
    		}
    		
    		if(DP.shape == 0){
    			return;
    		}else if(DP.shape == 1){
    			//stopped drawing from smallest to biggest x and y
    			DP.shapesList.add(new MyRectangle(x1,y1,e.getX(),e.getY()));
    			//also added an alternative for addShapeM
    		}else if (DP.shape == 2){
    			DP.shapesList.add(new MyEllipse(x1,y1,e.getX(),e.getY()));
    		}else if(DP.shape == 3){
    			DP.shapesList.add(new MyLine(x1,y1,e.getX(),e.getY()));
    		}else{
    			return;
    		}
    		delete = true;
    		DP.repaint();
    	}else if(DP.mode == 1){
    		
    		//new code ----------------------------------------
    		DP.updateMoveDrawable(e.getX(), e.getY());
    		//
    		
    		//pas coordinaten aan
    		//double deltax = e.getX()-x1;
    		//double deltax2 = DP.selectedShape.getX2() - e.getX();
    		//double deltay = e.getY()-y1;
    		//double deltay2 = DP.selectedShape.getY2()-e.getY();
    		
    		//DP.selectedShape.setCoordinates(DP.selectedShape.getX1()+deltax,DP.selectedShape.getY1()+deltay,DP.selectedShape.getX2()+deltax,DP.selectedShape.getY2()+deltay);
    		//DP.repaint();
    		//System.out.println((DP.selectedShape.getX1()+deltax) + ", " + (DP.selectedShape.getY1()+deltay) + ", " + (DP.selectedShape.getX2()+deltax) + ", " + (DP.selectedShape.getY2()+deltay));
    		//System.out.println("= "+ deltax + ", " + deltay);
    		/*

    		double width = 0, height = 0;
    		double x1u = 0, x2u = 0, y1u = 0, y2u = 0; 
    		
    		//System.out.println(x2 + ", " + y2);
    		
    		boolean selected = false;
    		String shape = null;

    		int c = DP.shapesListValues.size()-1;
			
			for(DrawnShapes s: DP.shapesListValues) {
				shape = s.shape;
				x1 = s.x1;
				y1 = s.y1;
				x2 = s.x2;
				y2 = s.y2;
				
					if(e.getX() >= x1 && e.getX() <= x2 && e.getY() >= y1 && e.getY() <= y2){
						  x1u = x1;
						  x2u = x2;
						  y1u = y1;
						  y2u = y2;
						  selected = true;
						  break;
				  	}else if(e.getX() <= x1 && e.getX() >= x2 && e.getY() >= y1 && e.getY() <= y2){
				  		  x1u = x2;
						  x2u = x1;
						  y1u = y1;
						  y2u = y2;
						  selected = true;
						  break;
				  	}else if(e.getX() >= x1 && e.getX() <= x2 && e.getY() <= y1 && e.getY() >= y2){
				  		  x1u = x1;
						  x2u = x2;
						  y1u = y2;
						  y2u = y1;
						  selected = true;
						  break;
				  	}else if(e.getX() <= x1 && e.getX() >= x2 && e.getY() <= y1 && e.getY() >= y2){
				  		  x1u = x2;
						  x2u = x1;
						  y1u = y2;
						  y2u = y1;
						  selected = true;
						  break;
					}
				c--;
			}
			
			if(selected == true){
				//System.out.println(shape + " selected: width " + width + ", height " + height);
				
				
				width = x2u-x1u;
	  			height = y2u-y1u;
				
	  			x1u = e.getX() - x1u;
	  			x2u = x1u + width;
	  			y1u = e.getY() - y1u;
	  			y2u = y1u + height;
				
	  			System.out.println();
	  			System.out.println(c);
	  			System.out.println("e.getX: " + e.getX() + ", e.getY: " + e.getY());
	  			System.out.println("x1: " + x1 + ", y1: " + y1 + ", x2: " + x2 + ", y2: " + y2);
	  			System.out.println("x1u: " + x1u + ", y1u: " + y1u + ", x2u: " + x2u + ", y2u: " + y2u);
				
				//if(delete == true){
	    		//	DP.deleteShapeB();
	    		}//
	    		
	    		if(shape == "MyRectangle"){
	    			DP.shapesList.set(c, new MyRectangle(x1u,y1u,x2u,y2u));
					DP.shapesListValues.set(c, new DrawnShapes("MyRectangle", x1u, y1u, x2u, y2u));
	    		}else if (shape == "MyEllipse"){
	    			DP.shapesList.set(c, new MyEllipse(x1u,y1u,x2u,y2u));
					DP.shapesListValues.set(c, new DrawnShapes("MyEllipse", x1u, y1u, x2u, y2u));
	    		}//else if(shape == "MyLine"){
	    		//	DP.shapesList.add(new MyLine(x1,y1,x2,y2));
	    		//	DP.shapesListValues.add(new DrawnShapes("MyLine", x1, y1, x2, y2));
	    		}//
	    		
	    		//delete = true;
			}
			
			DP.repaint();*/
    	}
    	else if (DP.mode == 2){ 
    		// Delete shapes on drag / wipe
    		DP.deleteShapeM(e.getX(),e.getY());
    		DP.repaint();
    	}
	}
	@Override
	public void mouseMoved(MouseEvent e) {
	}

}
