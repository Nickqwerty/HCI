/*
 * RightPanel.java file
 * Contains all the widgets in the RightPanel on the screen
 */

/*
 * Package location
 */
package nl.ru.ai.panels;

/*
 * Import packages?
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JPanel;

import nl.ru.ai.objects.Buttons;
import nl.ru.ai.objects.Labels;

/*
 * LeftPanel class
 * 
 * JPanel = superclass
 * RightPanel = subclass
 * 
 * The extending class becomes a subclass, it inherits the methods and variables of the superclass.
 */
public class RightPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	
	DrawPanel DP;
	public ColorPicker CPick;
	Labels Notifications;

	public RightPanel (Labels Notifications, DrawPanel DP) {
		super (); // `super ' calls a function inherited from the parent class ( JPanel )
		this.DP = DP;
		this.Notifications = Notifications;
		
		/* PANEL SETTINGS - START */
		setPreferredSize(new Dimension(20, Window.HEIGHT)); // Set fixed size
		setBackground(Color.DARK_GRAY); // Set background color
		/* PANEL SETTINGS - END */
		
		
		//Add a button to the panel . The argument to the JButton constructor will become the text on the button.
		Buttons Test = new Buttons("<",30,30,Notifications,"","Open right menu to modify",null,this);
		Test.setActionCommand("open");
		add (Test);
		
		CPick = new ColorPicker(DP);
		CPick.setVisible(false);
		add(CPick);
	}
}