/*
 * TopPanel.java file
 * Contains all the buttons in the TopMenu on the screen
 */

/*
 * Package location
 */
package nl.ru.ai.panels;

/*
 * Import packages?
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import nl.ru.ai.objects.Buttons;
import nl.ru.ai.objects.Labels;

/*
 * LeftPanel class
 * 
 * JPanel = superclass
 * TopPanel = subclass
 * 
 * The extending class becomes a subclass, it inherits the methods and variables of the superclass.
 */
public class TopPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	
	DrawPanel DP;
	Labels Notifications;
	RightPanel RP;

	public TopPanel (Labels Notifications, DrawPanel DP,RightPanel RP) {
		super (); // `super ' calls a function inherited from the parent class ( JPanel )
		this.DP = DP;
		this.Notifications = Notifications;
		this.RP = RP;
		
		/* PANEL SETTINGS - START */
		setPreferredSize(new Dimension(Window.WIDTH, 40)); // Set fixed size
		setBackground(Color.DARK_GRAY); // Set background color
		/* PANEL SETTINGS - END */
		
		
		/* MENU ITEMS - START */
		Buttons Save = new Buttons("Save File",100,30,Notifications,"","Save drawpanel to file.",DP,RP);
		Save.setActionCommand("Save");
		add (Save);
		
		Buttons Grid = new Buttons("Set Grid",100,30,Notifications,"","Set grid size.",DP,RP);
		Grid.setActionCommand("Grid");
		add (Grid);
		
		Buttons Clear = new Buttons("Clear screen",100,30,Notifications,"","The canvas will be cleared.",DP,RP);
		Clear.setActionCommand("Clear");
		add (Clear);
		
		Buttons Back = new Buttons("Back",100,30,Notifications,"","Last action will be deleted.",DP,RP);
		Back.setActionCommand("Back");
		add (Back);
		/* MENU ITEMS - END */
	}
}