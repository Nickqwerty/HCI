package nl.ru.ai.panels;
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class ColorPicker extends JPanel {
public static final DrawPanel DrawPanel = null;
DrawingCanvas canvas = new DrawingCanvas(); // canvas that changes to the selected color
  JLabel rgbValue = new JLabel(""); // rgbValue label
  JSlider sliderR, sliderG, sliderB, sliderAlpha; // assign slider values

  /*
   * Color panel with sliders and color representation
  */
  
  DrawPanel DP;
  Color color;
  
  public ColorPicker(DrawPanel DP) {
	this.DP = DP;
	
	this.setBackground(Color.white);
	
    sliderR = getSlider(0, 255, 0, 60, 20); // Red
    sliderG = getSlider(0, 255, 0, 60, 20); // Green
    sliderB = getSlider(0, 255, 0, 60, 20); // Blue
    sliderAlpha = getSlider(0, 255, 255, 60, 20); // Alpha

    JPanel LPanel = new JPanel();
    JPanel RPanel = new JPanel();
    
    LPanel.setPreferredSize(new Dimension(35, 300));
    LPanel.setLayout(new GridLayout(6, 1, 10, 0));
    
    RPanel.setPreferredSize(new Dimension(135, 300));
    RPanel.setLayout(new GridLayout(6, 1, 10, 0));
    
    LPanel.add(new JLabel("Red", JLabel.RIGHT));
    RPanel.add(sliderR);
    LPanel.add(new JLabel("Green", JLabel.RIGHT));
    RPanel.add(sliderG);
    LPanel.add(new JLabel("Blue", JLabel.RIGHT));
    RPanel.add(sliderB);

    LPanel.add(new JLabel("Alpha", JLabel.RIGHT));
    RPanel.add(sliderAlpha);

    LPanel.add(new JLabel("HEX", JLabel.RIGHT));
    rgbValue.setBackground(Color.white);
    rgbValue.setForeground(Color.black);
    rgbValue.setOpaque(true);
    RPanel.add(rgbValue);
    
    LPanel.add(new JLabel("Color", JLabel.RIGHT));
    RPanel.add(canvas);

    add(LPanel, BorderLayout.SOUTH);
    add(RPanel, BorderLayout.SOUTH);
  }

  public JSlider getSlider(int min, int max, int init, int mjrTkSp, int mnrTkSp) {
    JSlider slider = new JSlider(JSlider.HORIZONTAL, min, max, init);
    slider.setPaintTicks(true);
    slider.setMajorTickSpacing(mjrTkSp);
    slider.setMinorTickSpacing(mnrTkSp);
    slider.setPaintLabels(true);
    slider.addChangeListener(new SliderListener());
    return slider;
  }

  class DrawingCanvas extends Canvas {
    Color color;
    int redValue, greenValue, blueValue;
    int alphaValue = 255;

    public DrawingCanvas() {
      setSize(120, 30);
      color = new Color(0, 0, 0);
      setBackgroundColor();
      // https://docs.oracle.com/javase/tutorial/uiswing/misc/trans_shaped_windows.html
    }

    public void setBackgroundColor() {
    	//System.out.println(alphaValue);
    	color = new Color(redValue, greenValue, blueValue, alphaValue);
    	setBackground(color);	
    	//setBackground(new Color(redValue, greenValue, blueValue, alphaValue));
    }
    

    public void setBColor() {
    	// Set the BColor of the DrawPanel
    	//System.out.println(color);
    	DP.BColor = color;
    }
  }

  class SliderListener implements ChangeListener {
    public void stateChanged(ChangeEvent e) {
      JSlider slider = (JSlider) e.getSource();

      if (slider == sliderAlpha) {
        canvas.alphaValue = slider.getValue();
        canvas.setBackgroundColor();
      } else if (slider == sliderR) {
        canvas.redValue = slider.getValue();
        displayRGBColor();
      } else if (slider == sliderG) {
        canvas.greenValue = slider.getValue();
        displayRGBColor();
      } else if (slider == sliderB) {
        canvas.blueValue = slider.getValue();
        displayRGBColor();
      }
      canvas.repaint();
    }

    public void displayRGBColor() {
      canvas.setBackgroundColor();
      canvas.setBColor();
  // RGB to HEX
  // hex -> "ffff0000"
  String hex = Integer.toHexString(canvas.color.getRGB());
  // Reduced to RGB: hex -> "#ff0000"
  hex = "#" + hex.substring(2, hex.length());
  rgbValue.setText(hex.toUpperCase());
    }
    
  }
}