package nl.ru.ai.handlers;

import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import nl.ru.ai.panels.DrawPanel;
import nl.ru.ai.shapes.*;

public class MouseMotionHandler implements MouseMotionListener{

	DrawPanel DP;
	static boolean delete = false;
	
	static double x1,y1,x2,y2;
	public MouseMotionHandler (DrawPanel DP) {
		this.DP = DP;
	}
	
	// Store MyLine coordinates
	double l1, l2;
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
	 */
	//@Override
	public void mouseDragged(MouseEvent e) {
    	if(DP.mode == 0){
    		// if trigger to not delete the first placed shape
    		if(delete == true){
    			DP.deleteShapeB();
    		}
    		
    		if(DP.shape == 0){
    			return;
    		}else if(DP.shape == 1){
    			//stopped drawing from smallest to biggest x and y
    			DP.shapesList.add(new MyRectangle(x1,y1,e.getX(),e.getY()));
    			//also added an alternative for addShapeM
    		}else if (DP.shape == 2){
    			DP.shapesList.add(new MyEllipse(x1,y1,e.getX(),e.getY()));
    		}else if(DP.shape == 3){
    			DP.shapesList.add(new MyLine(x1,y1,e.getX(),e.getY()));
    		}else{
    			return;
    		}
    		delete = true;
    		DP.repaint();
    	}else if(DP.mode == 1){
    		
    		//new code ----------------------------------------
    		DP.updateMoveDrawable(e.getX(), e.getY());
    		//
    	}
    	else if (DP.mode == 2){ 
    		// Delete shapes on drag / wipe
    		DP.deleteShapeM(e.getX(),e.getY());
    		DP.repaint();
    	}else if(DP.mode == 4){
    		DP.resizeDrawable(e.getX(),e.getY());
    	}
	}
	//@Override
	public void mouseMoved(MouseEvent e) {
	}

}
