/*
 * MouseHandler.java file
 * Contains all the buttons in the LeftPanel on the screen
 */

/*
 * Package location
 */
package nl.ru.ai.handlers;

/*
 * Import packages?
 */
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import nl.ru.ai.Drawable;
import nl.ru.ai.panels.DrawPanel;

/*
 * MouseHandler class
 * 
 * MouseListener = superclass
 * MouseHandler = subclass
 * 
 * The extending class becomes a subclass, it inherits the methods and variables of the superclass.
 */
public class MouseHandler implements MouseListener{
	
	DrawPanel DP;

	double x1,y1,x2,y2;
	
	public MouseHandler (DrawPanel DP) {
		this.DP = DP;
	}
	
	//@Override
    public void mouseClicked(MouseEvent e) {
		System.out.println(e.getX() + ", " + e.getY());
    }
    
	// @Override
	    public void mousePressed(MouseEvent e) {	
	    	x1 = e.getX();
	    	MouseMotionHandler.x1 = x1;
	    	y1 = e.getY();
	    	MouseMotionHandler.y1 = y1;
	    	
	    	if(DP.mode == 1 || DP.mode == 4){	    		
	    		for(Drawable s: DP.shapesList) {
					if(e.getX() >= s.getX1() && e.getX() <= s.getX2() && e.getY() >= s.getY1() && e.getY() <= s.getY2()){
						  DP.selectedShape = s;
						  //new code 
						  DP.startMoveDrawable(e.getX(),e.getY());
						  //
						  break;
				  	}else if(e.getX() <= s.getX1() && e.getX() >= s.getX2() && e.getY() >= s.getY1() && e.getY() <= s.getY2()){
				  		  DP.selectedShape = s;
				  		  //new code 
						  DP.startMoveDrawable(e.getX(),e.getY());
						  //
						  break;
				  	}else if(e.getX() >= s.getX1() && e.getX() <= s.getX2() && e.getY() <= s.getY1() && e.getY() >= s.getY2()){
				  		  DP.selectedShape = s;
				  		  //new code 
						  DP.startMoveDrawable(e.getX(),e.getY());
						  //
						  break;
				  	}else if(e.getX() <= s.getX1() && e.getX() >= s.getX2() && e.getY() <= s.getY1() && e.getY() >= s.getY2()){
				  		   DP.selectedShape = s;
				  		   //new code
						   DP.startMoveDrawable(e.getX(),e.getY());
						   //
						  break;
					}	
	    	    }
	    	} else if(DP.mode == 2){
	    		DP.deleteShapeM(x1, y1);
	    	} else if(DP.mode == 4){

	    		for(Drawable s: DP.shapesList) {
					if(e.getX() >= s.getX1() && e.getX() <= s.getX2() && e.getY() >= s.getY1() && e.getY() <= s.getY2()){
						  DP.selectedShape = s;
						  //new code 
						  System.out.print(DP.BColor);
						  DP.fillShape();
						  //
						  break;
				  	}else if(e.getX() <= s.getX1() && e.getX() >= s.getX2() && e.getY() >= s.getY1() && e.getY() <= s.getY2()){
				  		  DP.selectedShape = s;
				  		  //new code 
				  		System.out.print(DP.BColor);
						  //
						  break;
				  	}else if(e.getX() >= s.getX1() && e.getX() <= s.getX2() && e.getY() <= s.getY1() && e.getY() >= s.getY2()){
				  		  DP.selectedShape = s;
				  		  //new code 
				  		System.out.print(DP.BColor);
						  //
						  break;
				  	}else if(e.getX() <= s.getX1() && e.getX() >= s.getX2() && e.getY() <= s.getY1() && e.getY() >= s.getY2()){
				  		   DP.selectedShape = s;
				  		   //new code
				  		 System.out.print(DP.BColor);
						   //
						  break;
					}	
	    	    }
	    		
	    	}
	    }
    
	 //@Override
	    public void mouseReleased(MouseEvent e) {
	    	MouseMotionHandler.delete = false;
	    	//new code
	    	DP.finishMoveDrawable();
	    }
    
    //@Override
    public void mouseEntered(MouseEvent e) {
    }
    
    //@Override
    public void mouseExited(MouseEvent e) {
    }
}