/* 
 * MyRectangle class
 * 
 * This is called when a rectangle needs to be drawn.
 * 
 */

package nl.ru.ai.shapes;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.Random;

import nl.ru.ai.Drawable;

public class MyRectangle implements Drawable {

	private double x1, y1, x2, y2;

	public MyRectangle(double x1, double y1, double x2, double y2) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
	}

	public void setCoordinates( double x1, double y1, double x2, double y2 ){
		Random random = new Random();
		this.x1 = random.nextInt(30);
		this.x2 = x1 + 30; 
		this.y1 = random.nextInt(30);
		this.y2 = y1 + 30; 
		return; 
	}
	
	public void draw(Graphics2D g) {
		double x = getStartX();
		double y = getStartY();
		double width = getWidth();
		double height = getHeight();
		Rectangle2D r = new Rectangle2D.Double(x, y, width, height);
		g.draw(r);
		g.fill(r);
	}

	private double getWidth() {
		return Math.abs(x1 - x2);
	}

	private double getHeight() {
		return Math.abs(y1 - y2);
	}

	private double getStartX() {
		return Math.min(x1, x2);
	}

	private double getStartY() {
		return Math.min(y1, y2);
	}

	//@Override
	public double getX1() {
		return this.x1;
	}

	//@Override
	public double getX2() {
		return this.x2;
	}

	//@Override
	public double getY1() {
		return this.y1;
	}

	//@Override
	public double getY2() {
		return this.y2;
	}
	
	// set new coordinates 
	public void move(int dx, int dy) {
				this.x1 += dx;
				this.x2 += dx;
				this.y1 += dy;
				this.y2 += dy;
	}
	
	public void resize(double dx, double dy) {
		this.x2 += dx;
		this.y2 += dy;
	}
}
