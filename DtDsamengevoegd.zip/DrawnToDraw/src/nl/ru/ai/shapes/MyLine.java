/* 
 * MyLine class
 * 
 * This is called when a line needs to be drawn.
 * 
 *  1 = begin lijn horizontaal
* 2 = einde lijn horizontaal
* 3 = einde lijn verticaal
* 4 = begin lijn verticaal
* */

package nl.ru.ai.shapes;

import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.util.Random;

import nl.ru.ai.Drawable;

public class MyLine implements Drawable {

	private double x1,x2,y1,y2;
	
	public MyLine(double x1, double x2, double y1, double y2){
		this.x1 = x1;
		this.x2 = x2; 
		this.y1 = y1;
		this.y2 = y2; 
	}
	
	public void setCoordinates( double x1, double y1, double x2, double y2 ){
		Random random = new Random();
		this.x1 = random.nextInt(30);
		this.x2 = x1 + 30; 
		this.y1 = random.nextInt(30);
		this.y2 = y1 + 30; 
		return; 
	}
	
	public void draw(Graphics2D g){
		//switched x2 and y1
		//stopped drawing from smallest values to biggest
		Line2D l = new Line2D.Double(x1,x2,y1,y2);
		g.draw(l);
	}

	//@Override
	public double getX1() {
		return this.x1;
	}

	//@Override
	public double getX2() {
		return this.x2;
	}

	//@Override
	public double getY1() {
		return this.y1;
	}

	//@Override
	public double getY2() {
		return this.y2;
	}
	
	// set new coordinates 
	public void move(int dx, int dy) {
				this.x1 += dx;
				this.x2 += dx;
				this.y1 += dy;
				this.y2 += dy;
	}
	
	public void resize(double dx, double dy) {
		this.x2 += dx;
		this.y2 += dy;
	}
}
