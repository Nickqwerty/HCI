package nl.ru.ai;

import java.awt.Graphics2D;

public interface Drawable {
	public void draw(Graphics2D g);
	public void setCoordinates( double x1, double y1, double x2, double y2 );
	public double getX1();
	public double getX2();
	public double getY1();
	public double getY2();
	
	//move the shape 
	public void move(int dx, int dy);
 
	public void resize(double dx, double dy);
}